//root tail compile time defaults

#define DEF_COLOR       "white"

//default font.. -font at runtime should work
#define USE_FONT        "fixed"

//default positions.. can be changed with -g at runtime
#define STD_WIDTH       160
#define STD_HEIGHT      20
#define LOC_X           30
#define LOC_Y           30

#define VERSION "0.2"

